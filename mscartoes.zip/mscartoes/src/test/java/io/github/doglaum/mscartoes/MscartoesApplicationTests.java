package io.github.doglaum.mscartoes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MscartoesApplicationTests {

	@Test
	void contextLoads() {
	}

}
